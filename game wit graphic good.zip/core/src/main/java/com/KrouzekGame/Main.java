package com.KrouzekGame;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.ScreenUtils;

import java.util.ArrayList;

public class Main extends ApplicationAdapter {

    Texture text;
    Image postavicka;
    Rectangle hitboxHrace;
    ArrayList<Prekazka> prekazky = new ArrayList<Prekazka>();
    Stage stage;
    ArrayList<NPC> npccka = new ArrayList<NPC>();
    Float otoceniHrace;
    ArrayList<Strela> strely;
    boolean byloNPCckoHitnuto = false;
    int npcTimer = 0;
    Sound zvuk;

    @Override
    public void create () {
        zvuk = Gdx.audio.newSound(Gdx.files.internal("gunshot-short.mp3"));

        text = new Texture("badlogic.png");
        strely = new ArrayList<>();
        postavicka = new Image(text);
        postavicka.setSize(200, 200);
        prekazky.add(new Prekazka(1000, 200, 50,50));
        prekazky.add(new Prekazka(500, 600, 50,50));
        prekazky.add(new Prekazka(500, 200, 50,50));
        hitboxHrace = new Rectangle(postavicka.getX(), postavicka.getY(), postavicka.getWidth(), postavicka.getHeight());
        stage = new Stage();
        stage.addActor(postavicka);
        npccka.add(new NPC(1000,500));
        npccka.add(new NPC(0,0));
        npccka.add(new NPC(0,500));

        for(Prekazka p : prekazky){
            stage.addActor(p);
        }

        for(NPC n : npccka){
            stage.addActor(n);
        }

        postavicka.setOrigin(postavicka.getWidth()/2, postavicka.getHeight()/2);
    }

    @Override
    public void render () {
        ScreenUtils.clear(1, 1, 1, 0);

        if(Gdx.input.isKeyPressed(Input.Keys.W)){
            postavicka.moveBy(0,10);
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(0,-10);
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.S)){
            postavicka.moveBy(0,-10);
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(0,10);
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.A)){
            postavicka.moveBy(-10,0);
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(10,0);
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.D)){
            postavicka.moveBy(10,0);
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(-10,0);
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }
        if(Gdx.input.isKeyJustPressed(Input.Keys.SPACE)){
            Strela strela = new Strela(postavicka.getX(), postavicka.getY(), otoceniHrace);
            stage.addActor(strela);
            strely.add(strela);
            zvuk.play();
        }

        otocHraceZaMysi();
        zkontrolujKolize();

        stage.act();
        stage.draw();
    }

    @Override
    public void dispose () {

    }

    void zkontrolujKolize(){
        ArrayList<Strela> strelyKeSmazani = new ArrayList<>();
        ArrayList<NPC> npcckaKeSmazani = new ArrayList<>();

        for(Strela s : strely){
            for(Prekazka p : prekazky){
                if(s.hitbox.overlaps(p.hitbox)){
                    System.out.println("HIT");
                    s.remove();
                    strelyKeSmazani.add(s);
                }
            }

            for(NPC n : npccka){
                if(s.hitbox.overlaps(n.hitbox)){
                    System.out.println("HIT");
                    s.remove();
                    n.remove();
                    strelyKeSmazani.add(s);
                    npcckaKeSmazani.add(n);
                }
            }
        }

        npccka.removeAll(npcckaKeSmazani);
        npcckaKeSmazani = null;
        strely.removeAll(strelyKeSmazani);
        strelyKeSmazani = null;
    }

    boolean muzeHracProjit(){

        for(Prekazka p : prekazky){
            if(hitboxHrace.overlaps(p.hitbox)){
                return false;
            }
        }

        return true;
    }

    void otocHraceZaMysi(){
        float mysX = Gdx.input.getX();
        float mysY = Gdx.graphics.getHeight()-Gdx.input.getY();

        float hracX = postavicka.getX() + postavicka.getOriginX();
        float hracY = postavicka.getY() + postavicka.getOriginY();

        float angle =  180+(float)Math.toDegrees((float) Math.atan2(hracY-mysY, hracX-mysX));
        otoceniHrace = angle;
    }
}
