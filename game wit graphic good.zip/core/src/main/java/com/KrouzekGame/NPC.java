package com.KrouzekGame;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

public class NPC
    extends Image {
    Rectangle hitbox;

    public NPC(int x, int y){
        super(new Texture("enemy.jpg"));
        setPosition(x, y);
        hitbox = new Rectangle(x, y, getWidth(), getHeight());
    }

    @Override
    public void act(float delta) {
        super.act(delta);
        hitbox.setPosition(getX(), getY());
    }
}
