package com.Projekt;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.ScreenUtils;

public class Main extends ApplicationAdapter {

    Texture text;
    Image postavicka;
    Stage stage;
    @Override
    public void create () {
        text = new Texture("quail.png");
        postavicka = new Image(text);
        postavicka.setSize(200, 200);
        stage = new Stage();
        stage.addActor(postavicka);
    }

    @Override
    public void render () {
        ScreenUtils.clear(1, 0, 1, 0);

        if(Gdx.input.isKeyPressed(Input.Keys.W)){
            postavicka.moveBy(0,10);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.S)){
            postavicka.moveBy(0,-10);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.A)){
            postavicka.moveBy(-10,0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.D)){
            postavicka.moveBy(10,0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
            Strela strela = new Strela(postavicka.getX(), postavicka.getY());
            stage.addActor(strela);
        }

        stage.act();
        stage.draw();
    }

    @Override
    public void dispose () {

    }
}
