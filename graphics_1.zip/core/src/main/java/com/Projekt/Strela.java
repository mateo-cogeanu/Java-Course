package com.Projekt;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

public class Strela extends Image {
    Strela(float x, float y){
        super(new Texture("bullet.png"));

        setPosition(x, y);
        setSize(100, 100);
    }

    @Override
    public void act(float delta) {
        moveBy(5,0);
    }
}
