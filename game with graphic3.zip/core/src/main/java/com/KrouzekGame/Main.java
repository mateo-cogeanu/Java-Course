package com.KrouzekGame;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FillViewport;

import java.util.ArrayList;

public class Main extends ApplicationAdapter {

    Texture text;
    Image postavicka;
    Rectangle hitboxHrace;
    ArrayList<Prekazka> prekazky = new ArrayList<Prekazka>();
    Stage stage;
    ArrayList<NPC> npccka = new ArrayList<NPC>();
    Float otoceniHrace;
    ArrayList<Strela> strely;
    boolean byloNPCckoHitnuto = false;
    int npcTimer = 0;
    Sound zvuk;

    @Override
    public void create () {
        zvuk = Gdx.audio.newSound(Gdx.files.internal("gunshot-short.mp3"));

        text = new Texture("badlogic.jpg");
        strely = new ArrayList<>();
        postavicka = new Image(text);
        postavicka.setSize(200, 200);
       /* prekazky.add(new Prekazka(1000, 200, 50,50));
        prekazky.add(new Prekazka(500, 600, 50,50));
        prekazky.add(new Prekazka(500, 200, 50,50));*/
        hitboxHrace = new Rectangle(postavicka.getX(), postavicka.getY(), postavicka.getWidth(), postavicka.getHeight());

        stage = new Stage();
        stage.setViewport(new FillViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight()));
        stage.getViewport().setCamera(new OrthographicCamera());
        stage.getCamera().position.x = postavicka.getX()+postavicka.getWidth()/2;
        stage.getCamera().position.y = postavicka.getY()+postavicka.getHeight()/2;
        stage.getViewport().update(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        stage.getViewport().apply();


        stage.addActor(postavicka);
        npccka.add(new NPC(1000,500, this));
        npccka.add(new NPC(0,0, this));
        npccka.add(new NPC(0,500, this));

        for(Prekazka p : prekazky){
            stage.addActor(p);
        }

        for(NPC n : npccka){
            stage.addActor(n);
        }

        postavicka.setOrigin(postavicka.getWidth()/2, postavicka.getHeight()/2);
    }

    @Override
    public void render () {
        ScreenUtils.clear(1, 1, 1, 0);

        for (NPC n : npccka){
            n.hracX = postavicka.getX()+postavicka.getWidth()/2;
            n.hracY = postavicka.getY()+postavicka.getHeight()/2;
        }

        if(Gdx.input.isKeyPressed(Input.Keys.W)){
            postavicka.moveBy(0,10);
            stage.getCamera().translate(0, 10,0 );
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(0,-10);
                stage.getCamera().translate(0, -10,0 );
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.S)){
            postavicka.moveBy(0,-10);
            stage.getCamera().translate(0, -10,0 );
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(0,10);
                stage.getCamera().translate(0, 10,0 );
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.A)){
            postavicka.moveBy(-10,0);
            stage.getCamera().translate(-10, 0,0 );
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(10,0);
                stage.getCamera().translate(10, 0,0 );
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.D)){
            postavicka.moveBy(10,0);
            stage.getCamera().translate(10, 0,0 );
            hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            if(!muzeHracProjit()){
                postavicka.moveBy(-10,0);
                stage.getCamera().translate(-10, 0,0 );
                hitboxHrace.setPosition(postavicka.getX(), postavicka.getY());
            }
        }

        if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
            spawniStrelu(true, postavicka.getX(), postavicka.getY(),otoceniHrace);
        }

        otocHraceZaMysi();
        zkontrolujKolize();

        stage.act();
        stage.draw();
    }

    @Override
    public void dispose () {

    }

    void spawniStrelu(boolean odHrace, float x, float y, float rotation){
        Strela strela = new Strela(x, y, rotation, odHrace);
        stage.addActor(strela);
        strely.add(strela);
        zvuk.play();
    }

    void zkontrolujKolize(){
        ArrayList<Strela> strelyKeSmazani = new ArrayList<>();
        ArrayList<NPC> npcckaKeSmazani = new ArrayList<>();

        for(Strela s : strely){
            for(Prekazka p : prekazky){
                if(s.hitbox.overlaps(p.hitbox)){
                    System.out.println("HIT");
                    s.remove();
                    strelyKeSmazani.add(s);
                }
            }

            for(NPC n : npccka){
                if(s.hitbox.overlaps(n.hitbox)&&s.odHrace){
                    System.out.println("HIT");
                    s.remove();
                    n.remove();
                    strelyKeSmazani.add(s);
                    npcckaKeSmazani.add(n);
                }
            }

            if(s.hitbox.overlaps(hitboxHrace)&&!s.odHrace){
                s.remove();
                strelyKeSmazani.add(s);
            }
        }

        npccka.removeAll(npcckaKeSmazani);
        npcckaKeSmazani = null;
        strely.removeAll(strelyKeSmazani);
        strelyKeSmazani = null;
    }

    boolean muzeHracProjit(){

        for(Prekazka p : prekazky){
            if(hitboxHrace.overlaps(p.hitbox)){
                return false;
            }
        }

        return true;
    }

    void otocHraceZaMysi(){
        float mysX = Gdx.input.getX()+stage.getCamera().position.x-Gdx.graphics.getWidth()/2;
        float mysY = Gdx.graphics.getHeight()-Gdx.input.getY()+stage.getCamera().position.y-Gdx.graphics.getHeight()/2;

        float hracX = postavicka.getX() + postavicka.getOriginX();
        float hracY = postavicka.getY() + postavicka.getOriginY();

        float angle =  180+(float)Math.toDegrees((float) Math.atan2(hracY-mysY, hracX-mysX));
        otoceniHrace = angle;
    }
}
